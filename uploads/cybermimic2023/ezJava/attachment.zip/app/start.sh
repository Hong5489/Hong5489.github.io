#!/bin/sh
cd /app/
java -jar *.jar
