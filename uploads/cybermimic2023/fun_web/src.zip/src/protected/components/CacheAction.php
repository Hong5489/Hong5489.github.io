<?php

class CacheAction extends CAction
{
    public function run(array $param)
    {
        $controller = $this->getController();
        $controller->beginCache("cache", $param);
        Yii::app()->end();
    }
}