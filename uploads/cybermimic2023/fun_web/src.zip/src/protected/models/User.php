<?php

class User extends CModel
{

    public $Username;
    public function attributeLabels()
    {
        return array(
            'username' => 'Username',
        );
    }

    public function attributeNames()
    {
        // TODO: Implement attributeNames() method.
    }
}
