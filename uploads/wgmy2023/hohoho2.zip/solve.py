from Crypto.Util.number import *
from pwn import *
context.log_level = "debug"
m = 0xb00ce3d162f598b408e9a0f64b815b2f
k = (bytes_to_long(b"Santa Claus")-bytes_to_long(b"test"))*pow(m, -1,2**88)%2**88
x = bytes_to_long(b"test")+k*m
# p = process(["python3","server.py"])
p = remote("localhost",2000)
p.sendlineafter("option: ",'1')
p.sendlineafter("name: ","test")
p.sendlineafter("option: ",'2')
p.sendlineafter("name: ",long_to_bytes(x))
p.interactive()