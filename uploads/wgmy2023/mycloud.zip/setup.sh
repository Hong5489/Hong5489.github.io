mkdir /secret_folder
echo $FLAG > /secret_folder/flag.txt
cd /secret_folder
mv flag.txt flag-$(md5sum flag.txt | awk '{print $1}').txt
mkdir /drive
chmod 777 /drive
chmod 555 /secret_folder
service php8.2-fpm start
mysqld_safe &

while ! mysql -e "show databases;"; do # Wait for MariaDB
  sleep 1
done

mysql < /setup.sql
nginx
while true; do sleep 1000; done