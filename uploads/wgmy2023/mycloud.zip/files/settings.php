<?php
	session_start();
	ini_set('display_errors', 1);
	ini_set('display_startup_errors', 1);
	error_reporting(E_ALL);
	if (!isset($_SESSION["user_id"])){
		echo '<meta http-equiv="refresh" content="0;url=login.php">';
		die();
	}
?>
<html>

<head>
	<title>Settings</title>
	<script src="https://code.jquery.com/jquery-3.4.1.slim.js" integrity="sha256-BTlTdQO9/fascB1drekrDVkaKd9PkwBymMlHOiG+qLI=" crossorigin="anonymous"></script>
	<!-- Bootstrap core CSS -->
	<link href="./bootstrap.min.css" rel="stylesheet">
</head>

<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
		<div class="container">
			<img src="mycloud.jfif" height="50px" width="50px">
			<a class="navbar-brand" href="#">myCloud Drive</a>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse" id="navbarNav">
				<ul class="navbar-nav ml-auto">
					<li class="nav-item">
						<a class="nav-link" href="index.php">Home</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="drive.php">myCloud Drive</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="settings.php">Settings</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="logout.php">Logout</a>
					</li>
				</ul>
			</div>
		</div>
	</nav>
	<?php
		$conn = new mysqli("localhost","admin","admin","mycloud_db");
		if ($conn->connect_error) {
				die("Connection failed: " . $conn->connect_error);
		}
		$sql = "SELECT * FROM users WHERE id = ?";
		$stmt = $conn->prepare($sql);
		$id = intval($_SESSION["user_id"]);
		$stmt->bind_param("i",$id);
		$stmt->execute();
		$result = $stmt->get_result();
		$row = $result->fetch_assoc();
		if($row){
			$username = $row["username"];
			$password = $row["password"];
		}else{
			die("<h5 class='text-danger'>Error occured!</h5>");
		}
	?>
	 <div class="container mt-5">
		<h2 class="mb-4">Settings</h2>
		<form id="login-form" action="settings.php" method="post">
			<div class="mb-3">
				<label for="username" class="form-label">Username:</label>
				<input type="text" id="username" name="username" class="form-control" value="<?=htmlentities($username)?>" disabled>
			</div>
			<div class="mb-3">
				<label for="current_password" class="form-label">Current Password:</label>
				<input type="password" id="current_password" name="current_password" class="form-control" required>
			</div>
			<div class="mb-3">
				<label for="new_password" class="form-label">Password:</label>
				<input type="password" id="new_password" name="new_password" class="form-control" required>
			</div>
			<div class="text-center">
				<button type="submit" class="btn btn-primary">Update</button>
			</div>
		</form>
		<?php
			if(isset($_POST['username']) && isset($_POST['current_password']) && isset($_POST['new_password'])){
				if($_POST['current_password'] === $password){
					$sql = "UPDATE users SET username = ?, password = ? WHERE id = ?";
					$stmt = $conn->prepare($sql);
					$stmt->bind_param("ssi", $_POST['username'],$_POST['new_password'],$_SESSION['user_id']);
					$result = $stmt->execute();

					if($result){
						echo "<h5 class='text-success'>Updated successfully!</h5>";
					}else{
						echo "<h5 class='text-danger'>Error!!</h5>";
					}
				}else{
					echo "<h5 class='text-danger'>Wrong password!</h5>";
				}
			}
		?>
	</div>


</body>

</html>
