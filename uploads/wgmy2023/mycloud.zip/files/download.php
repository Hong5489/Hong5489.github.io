<?php
	session_start();
		ini_set('display_errors', 1);
		ini_set('display_startup_errors', 1);
		error_reporting(E_ALL);
	if (!isset($_SESSION["user_id"])){
		echo '<meta http-equiv="refresh" content="0;url=login.php">';
		die();
	}
	function getUsername(){
		$conn = new mysqli("localhost","admin","admin","mycloud_db");
		if ($conn->connect_error) {
			die("Connection failed: " . $conn->connect_error);
		}
		$sql = "SELECT * FROM users WHERE id = ?";
		$stmt = $conn->prepare($sql);
		$id = intval($_SESSION["user_id"]);
		$stmt->bind_param("i",$id);
		$stmt->execute();
		$result = $stmt->get_result();
		$row = $result->fetch_assoc();
		if($row){
			return $row["username"];
		}else{
			die("Error occured!!");
		}
	}
	if(isset($_GET['file']) && isset($_GET['hash'])){
		$path = realpath("/drive/".getUsername()."/".$_GET['file']);
		// Double protection against directory traversal
		if(strpos($path, "/drive") !== 0 || hash_hmac('sha256', $path , $_SESSION['SECRET']) !== $_GET['hash']){
			die("HACKER ALERT!!");
		}
		$filepath = realpath("/drive/".getUsername()."/".$_GET['file']);

		if (file_exists($filepath)) {
			header('Content-Description: File Transfer');
			header('Content-Type: application/octet-stream');
			header('Content-Disposition: attachment; filename="' . basename($filepath) . '"');
			header('Expires: 0');
			header('Cache-Control: must-revalidate');
			header('Pragma: public');
			header('Content-Length: ' . filesize($filepath));
			flush(); // Flush system output buffer
			readfile($filepath);
			die();
		} else {
		  http_response_code(404);
		  die();
		}
	}
?>