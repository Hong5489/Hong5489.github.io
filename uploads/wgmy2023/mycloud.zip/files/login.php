<?php 
	session_start();
	ini_set('display_errors', 1);
	ini_set('display_startup_errors', 1);
	error_reporting(E_ALL);
?>
<!doctype html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="description" content="">
		<meta name="author" content="Kuki Godam">
		<script src="https://code.jquery.com/jquery-3.4.1.slim.js" integrity="sha256-BTlTdQO9/fascB1drekrDVkaKd9PkwBymMlHOiG+qLI=" crossorigin="anonymous"></script>
		<title>Login</title>

		<!-- Bootstrap core CSS -->
		<link href="./bootstrap.min.css" rel="stylesheet">

		<!-- Custom styles for this template -->
		<link href="./style.css" rel="stylesheet">
	</head>
	<body class="text-center">
		<div class="container mt-5">
		<div class="row justify-content-center">
			<div class="col-md-6">
				<div class="card">
					<div class="card-header">
						<h2 class="text-center">Login myCloud Drive</h2>
					</div>
					<div class="card-body">
						<form id="login-form" action="login.php" method="post">
							<div class="mb-3">
								<label for="username" class="form-label">Username:</label>
								<input type="text" id="username" name="username" class="form-control" required>
							</div>
							<div class="mb-3">
								<label for="password" class="form-label">Password:</label>
								<input type="password" id="password" name="password" class="form-control" required>
							</div>
							<div class="text-center">
								<button type="submit" class="btn btn-primary">Login</button>
								<!-- Register Button -->
								<a href="register.php" class="btn btn-secondary">Register</a>
							</div>
						</form>
					</div>
		<?php 
			if(isset($_POST['username']) && isset($_POST['password'])){
				$conn = new mysqli("localhost","admin","admin","mycloud_db");
						if ($conn->connect_error) {
								die("Connection failed: " . $conn->connect_error);
						}
						$sql = "SELECT * FROM users WHERE username = ? and password = ?";
						$stmt = $conn->prepare($sql);
						$stmt->bind_param("ss", $_POST['username'],$_POST['password']);
						$stmt->execute();
						$result = $stmt->get_result();
				$row = $result->fetch_assoc();
						if($row){
					$_SESSION["user_id"] = $row["id"];
					$_SESSION["SECRET"] = $row["secret"];
					echo '<meta http-equiv="refresh" content="0;url=index.php">';
						}else{
					echo "<h5 class='text-danger'>Wrong username or password!</h5>";
						}
			}
		?>
				</div>
<p class="mt-5 mb-3 text-muted">© Kuki.Godam, 2023</p>
			</div>
		</div>
	</div>
</body>
</html>
