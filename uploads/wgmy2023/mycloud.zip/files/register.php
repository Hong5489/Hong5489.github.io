<?php 
	session_start();
	ini_set('display_errors', 1);
	ini_set('display_startup_errors', 1);
	error_reporting(E_ALL);
?>
<!doctype html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="description" content="">
		<meta name="author" content="Kuki Godam">
		<script src="https://code.jquery.com/jquery-3.4.1.slim.js" integrity="sha256-BTlTdQO9/fascB1drekrDVkaKd9PkwBymMlHOiG+qLI=" crossorigin="anonymous"></script>
		<title>Register</title>

		<!-- Bootstrap core CSS -->
		<link href="./bootstrap.min.css" rel="stylesheet">

		<!-- Custom styles for this template -->
		<link href="./style.css" rel="stylesheet">
	</head>
	<body class="text-center">
		<div class="container mt-5">
		<div class="row justify-content-center">
			<div class="col-md-6">
				<div class="card">
					<div class="card-header">
						<h2 class="text-center">Register myCloud Drive</h2>
					</div>
					<div class="card-body">
						<form id="login-form" action="register.php" method="post">
							<div class="mb-3">
								<label for="username" class="form-label">Username:</label>
								<input type="text" id="username" name="username" class="form-control" required>
							</div>
							<div class="mb-3">
								<label for="password" class="form-label">Password:</label>
								<input type="password" id="password" name="password" class="form-control" required>
							</div>
							<div class="text-center">
								<button type="submit" class="btn btn-primary">Register</button>
								<!-- Register Button -->
								<a href="login.php" class="btn btn-secondary">Login</a>
							</div>
						</form>
					</div>
					<?php

					if(isset($_POST['username']) && isset($_POST['password'])){
						$username = trim($_POST['username']);
						if (mkdir("/drive/".$username, 0700)){
							$conn = new mysqli("localhost","admin","admin","mycloud_db");
							if ($conn->connect_error) {
									die("Connection failed: " . $conn->connect_error);
							}
							$sql = "INSERT INTO users (username, password) VALUES (?,?)";
							$stmt = $conn->prepare($sql);
							$stmt->bind_param("ss", $username,$_POST['password']);
							$result = $stmt->execute();
							if($result){
								echo "<h5 class='text-success'>Registered successfully!</h5>";
							}else{
								echo "<h5 class='text-danger'>Registration failed</h5>";
							}
						}else{
							echo "<h5 class='text-danger'>Username already exist!</h5>";
						}
					}
					?>
				</div>
				<p class="mt-5 mb-3 text-muted">© Kuki.Godam, 2023</p>
			</div>
		</div>
	</div>
</body>
</html>
