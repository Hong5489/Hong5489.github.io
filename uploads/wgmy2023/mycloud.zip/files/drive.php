<?php
	session_start();
		ini_set('display_errors', 1);
		ini_set('display_startup_errors', 1);
		error_reporting(E_ALL);
	if (!isset($_SESSION["user_id"])){
		echo '<meta http-equiv="refresh" content="0;url=login.php">';
		die();
	}
	function getUsername(){
		$conn = new mysqli("localhost","admin","admin","mycloud_db");
		if ($conn->connect_error) {
			die("Connection failed: " . $conn->connect_error);
		}
		$sql = "SELECT * FROM users WHERE id = ?";
		$stmt = $conn->prepare($sql);
		$id = intval($_SESSION["user_id"]);
		$stmt->bind_param("i",$id);
		$stmt->execute();
		$result = $stmt->get_result();
		$row = $result->fetch_assoc();
		if($row){
			return $row["username"];
		}else{
			die("<h5 class='text-danger'>Error occured!</h5>");
		}
	}
	function humanFileSize($size,$unit="") {
		if( (!$unit && $size >= 1<<30) || $unit == "GB")
		return number_format($size/(1<<30),2)."GB";
		if( (!$unit && $size >= 1<<20) || $unit == "MB")
		return number_format($size/(1<<20),2)."MB";
		if( (!$unit && $size >= 1<<10) || $unit == "KB")
		return number_format($size/(1<<10),2)."KB";
		return number_format($size)." bytes";
	}
?>
<html>

<head>
	<title>myCloud</title>
	<script src="https://code.jquery.com/jquery-3.4.1.slim.js" integrity="sha256-BTlTdQO9/fascB1drekrDVkaKd9PkwBymMlHOiG+qLI=" crossorigin="anonymous"></script>
	<!-- Bootstrap core CSS -->
	<link href="./bootstrap.min.css" rel="stylesheet">
</head>

<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
		<div class="container">
			<img src="mycloud.jfif" height="50px" width="50px">
			<a class="navbar-brand" href="#">myCloud Drive</a>
			<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
				<span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse" id="navbarNav">
				<ul class="navbar-nav ml-auto">
					<li class="nav-item">
						<a class="nav-link" href="index.php">Home</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="drive.php">myCloud Drive</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="settings.php">Settings</a>
					</li>
					<li class="nav-item">
						<a class="nav-link" href="logout.php">Logout</a>
					</li>
				</ul>
			</div>
		</div>
	</nav>

	 <div class="container mt-5">
		<h2 class="mb-4">Current Folder: <?=htmlentities(realpath("/drive/".getUsername()))?></h2>

		<table class="table">
			<thead>
				<tr>
					<th>File Name</th>
					<th>Size</th>
					<th>Date</th>
					<th>Delete</th>
				</tr>
			</thead>
			<tbody>
				<?php
					if(isset($_POST["submit"])){
						$target_dir = realpath("/drive/".getUsername().'/');
						if(strpos($target_dir, "/drive") !== 0){
							die("<h5 class='text-danger'>HACKER ALERT!!</h5>");
						}
						$target_file = $target_dir .'/'. basename($_FILES["fileToUpload"]["name"]);
						
						if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
						echo "<h5 class='text-success'>The file ". htmlspecialchars( basename( $_FILES["fileToUpload"]["name"])). " has been uploaded.</h5>";
						} else {
						echo "<h5 class='text-danger'>Sorry, there was an error uploading your file.</h5>";
						}
					}
			
					$path = realpath("/drive/".getUsername());
					// Prevent directory traversal
					if(strpos($path, "/drive/") !== 0){
						die("<h5 class='text-danger'>HACKER ALERT!!</h5>");
					}

					// List all files in the user directory
					$basepath = realpath("/drive/".getUsername());
					$files = array_diff(scandir($basepath), array('..', '.'));
					foreach ($files as $key => $value) {
						$h = hash_hmac('sha256', $basepath.'/'.$value , $_SESSION['SECRET']);
						echo "<tr>";
						echo "<td><a href='download.php?file=".urlencode($value)."&hash=".urlencode($h)."'>".htmlentities($value)."</a></td>";
						echo "<td>".htmlentities(humanFileSize(filesize($basepath.'/'.$value)))."</td>";
						echo "<td>".htmlentities(date("F d Y H:i:s.",filemtime($basepath.'/'.$value)))."</td>";
						echo "<td><a href=\"javascript:alert('Coming Soon!!')\">🗑️</a></td>";
						echo "</tr>";
					}

					
				?>
			</tbody>
		</table>
		<form action="drive.php" method="post" enctype="multipart/form-data">
			<input type="file" name="fileToUpload" id="fileToUpload">
			<input class="btn btn-success mb-4" type="submit" value="Upload File" name="submit">
		</form>
	</div>


</body>

</html>
