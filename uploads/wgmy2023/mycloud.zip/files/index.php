<?php
	session_start();
	if (!isset($_SESSION["user_id"])){
		echo '<meta http-equiv="refresh" content="0;url=login.php">';
		die();
	}
?>
<html>

<head>
	<title>myCloud</title>
	<script src="https://code.jquery.com/jquery-3.4.1.slim.js" integrity="sha256-BTlTdQO9/fascB1drekrDVkaKd9PkwBymMlHOiG+qLI=" crossorigin="anonymous"></script>
	<!-- Bootstrap core CSS -->
	<link href="./bootstrap.min.css" rel="stylesheet">
</head>

<body>
<nav class="navbar navbar-expand-lg navbar-light bg-light">
	<div class="container">
		<img src="mycloud.jfif" height="50px" width="50px">
	    <a class="navbar-brand" href="#">myCloud Drive</a>
	    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
		<span class="navbar-toggler-icon"></span>
	    </button>
	    <div class="collapse navbar-collapse" id="navbarNav">
		<ul class="navbar-nav ml-auto">
		    <li class="nav-item">
			<a class="nav-link" href="index.php">Home</a>
		    </li>
		    <li class="nav-item">
			<a class="nav-link" href="drive.php">myCloud Drive</a>
		    </li>
		    <li class="nav-item">
			<a class="nav-link" href="settings.php">Settings</a>
		    </li>
		    <li class="nav-item">
			<a class="nav-link" href="logout.php">Logout</a>
		    </li>
		</ul>
	    </div>
	</div>
    </nav>

    <div class="container mt-5">
	<div class="row">
	    <div class="col-md-8">
		<h1>Welcome to myCloud Drive</h1>
		<p>myCloud Drive is a cloud storage service that allows you to store your files securely in the cloud. With myCloud Drive, you can access your files from any device, share them with others, and collaborate in real-time.</p>
		<p>Key features:</p>
		<ul>
		    <li>Store and sync your documents, photos, and more across all your devices.</li>
		    <li>Share files and folders with friends and colleagues.</li>
		    <li>Access your files from anywhere with an internet connection.</li>
		    <li>Secure and private storage with military-grade encryption.</li>
		</ul>
	    </div>
	</div>
    </div>


</body>

</html>
