CREATE DATABASE mycloud_db;

GRANT SELECT,INSERT,UPDATE,DELETE ON mycloud_db.* TO 'admin'@'%' IDENTIFIED BY 'admin';
USE mycloud_db;

CREATE TABLE users (
        id int NOT NULL AUTO_INCREMENT PRIMARY KEY,
        username varchar(100),
        password varchar(100),
        secret varchar(32) DEFAULT MD5(RANDOM_BYTES(16))
);