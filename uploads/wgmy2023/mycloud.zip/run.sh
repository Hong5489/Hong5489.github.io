#!/bin/bash

docker build -t mycloud .
docker stop -t 0 mycloud
docker run -d -e FLAG=wgmy{0a8d216f13c4308ed1b5d17fc99384d2} --rm --name mycloud -p 1337:80 mycloud