from Crypto.Util.number import *
from pwn import *
context.log_level = "debug"
m = 0xb00ce3d162f598b408e9a0f64b815b2f
a = 0xaaa87c7c30adc1dcd06573702b126d0d
c = 0xcaacf9ebce1cdf5649126bc06e69a5bb
x = pow(1-a,-1,m)*c
k = (bytes_to_long(b"Santa Claus")-x)*pow(m, -1,2**88)%2**88
token = hex((a*x+c)%m)[2:]
x = x+k*m
print(token)
# p = process(["python3","server.py"])
p = remote("localhost",2000)
p.sendlineafter("option: ",'2')
p.sendlineafter("name: ",long_to_bytes(x))
p.interactive()