#!/bin/bash

useradd ctf
chown -R ctf:ctf /chall

cd chall

sudo -u ctf socat TCP-LISTEN:2000,reuseaddr,fork EXEC:'python3 server.py'&

while true; do sleep 1000; done