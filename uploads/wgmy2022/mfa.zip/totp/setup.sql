CREATE DATABASE dashboard_db;

GRANT SELECT,INSERT,UPDATE ON dashboard_db.* TO 'admin'@'%' IDENTIFIED BY 'admin';
USE dashboard_db;

CREATE TABLE users (
        username varchar(100) PRIMARY KEY,
        password varchar(100),
        secret varchar(150)
);

CREATE TABLE notes (
        title varchar(50),
        body varchar(200),
        username varchar(100)
);

INSERT INTO users (username, password, secret) VALUES ('godam','letmein','RUKTVQSRTNNBWNPCBVHK7TNLW2MBUUW5XWF5HJAUUEPVZVCHIKN3PGBFPTLRJQQ3NQGFX3BKYWXO4DUNEYOT5DSL7KC7K6K5RD32PIY');
INSERT INTO notes (title,body,username) VALUES ('Flag','wgmy{a3788e5d9f8fb9650aae12f12e24a0ca}','godam');