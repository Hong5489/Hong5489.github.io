<?php 
	session_start();
	unset($_SESSION['user']);
	unset($_SESSION['pass']);
	unset($_SESSION['auth']);
	echo '<meta http-equiv="refresh" content="0;url=login.php">';
?>