<?php
	session_start();
	if (!isset($_SESSION["user"]) or !$_SESSION["auth"]){
		echo '<meta http-equiv="refresh" content="0;url=login.php">';
		die();
	}
?>
<html>

<head>
	<title>Dashboard</title>
	<script src="https://code.jquery.com/jquery-3.4.1.slim.js" integrity="sha256-BTlTdQO9/fascB1drekrDVkaKd9PkwBymMlHOiG+qLI=" crossorigin="anonymous"></script>
	<!-- Bootstrap core CSS -->
	<link href="./bootstrap.min.css" rel="stylesheet">
</head>

<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark static-top">
	<div class="container">
		<a class="navbar-brand" href="index.php">Most Friendly App</a>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="navbarResponsive">
			<ul class="navbar-nav ml-auto">
				<li class="nav-item active">
					<a class="nav-link" href="index.php">Home</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="notes.php">Notes</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="logout.php">Logout</a>
				</li>
			</ul>
		</div>
	</div>
</nav>

<main role="main" class="container">
	<h1 class="mt-5">Welcome <?php echo htmlentities($_SESSION["user"]["username"]);?></h1>
	<p class="lead">Updated version 6.0</p>
	<ul>
		<li>Remove Impersonate page</li>
		<li>Fixed XSS bug</li>
		<li>MFA login feauture</li>
	</ul>
</main>

</body>

</html>
