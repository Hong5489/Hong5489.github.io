<?php 
	session_start();
    require 'vendor/autoload.php';
    use OTPHP\TOTP;
?>
<!doctype html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="description" content="">
		<meta name="author" content="Kuki Godam">
		<script src="https://code.jquery.com/jquery-3.4.1.slim.js" integrity="sha256-BTlTdQO9/fascB1drekrDVkaKd9PkwBymMlHOiG+qLI=" crossorigin="anonymous"></script>
		<title>Setup MFA</title>

		<!-- Bootstrap core CSS -->
		<link href="./bootstrap.min.css" rel="stylesheet">

		<!-- Custom styles for this template -->
		<link href="./style.css" rel="stylesheet">
	</head>
	<body class="text-center">
		<div class="col-xl-3">
		<h3>Setup MFA</h3>
		<h5>Now scan the QR code below with Google or Microsoft Authenticator app</h5>
		
		<?php
		if(isset($_GET['username'])){
			$conn = new mysqli("localhost","admin","admin","dashboard_db");
            if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
            }
            $sql = "SELECT * FROM users WHERE username = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $_GET['username']);
            $stmt->execute();
            $result = $stmt->get_result();
			$row = $result->fetch_assoc();
            if($row){
                $otp = TOTP::create($row["secret"]);
            	$otp->setLabel('SKR');
				$grCodeUri = $otp->getQrCodeUri(
				    'https://api.qrserver.com/v1/create-qr-code/?data=[DATA]&size=300x300&ecc=M',
				    '[DATA]'
				);
				echo "<img src='{$grCodeUri}'><form action='getQR.php' method='POST' class='mt-2'>";
				echo '<input type="password" name="otp" class="form-control" placeholder="OTP" required=""><input type="hidden" name="username" value="'.htmlentities($_GET['username']).'"><button class="btn btn-lg btn-primary btn-block mb-2" type="submit">Verify</button></form>';
            }else{
            	echo "<h5 class='text-danger'>Hacker Detected!</h5>";
            	echo '<meta http-equiv="refresh" content="0;url=login.php">';
            }
		}else if(isset($_POST['otp']) && isset($_POST['username'])){
			$conn = new mysqli("localhost","admin","admin","dashboard_db");
            if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
            }
            $sql = "SELECT * FROM users WHERE username = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $_POST['username']);
            $stmt->execute();
            $result = $stmt->get_result();
			$row = $result->fetch_assoc();
            if($row){
                $otp = TOTP::create($row["secret"]);
            	if($otp->verify($_POST['otp'])){
            		echo "<h5 class='text-success'>Verified successfully!</h5><p>Redirecting to login page..</p>";
            		echo '<meta http-equiv="refresh" content="0;url=login.php">';
            	}else{
            		echo "<h5 class='text-danger'>Wrong OTP! Please try again!</h5>";
            	}
            }else{
				echo "<h5 class='text-danger'>Hacker Detected!</h5>";
	            echo '<meta http-equiv="refresh" content="0;url=login.php">';
			}
		}else{
			echo "<h5 class='text-danger'>Hacker Detected!</h5>";
            echo '<meta http-equiv="refresh" content="0;url=login.php">';
		}
		?>
		
		
		</div>
</body>
</html>
