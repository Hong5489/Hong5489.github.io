<?php
	session_start();
	if (!isset($_SESSION["user"]) or !$_SESSION["auth"]){
		echo '<meta http-equiv="refresh" content="0;url=login.php">';
		die();
	}
?>
<html>

<head>
	<title>Notes</title>
	<script src="https://code.jquery.com/jquery-3.4.1.slim.js" integrity="sha256-BTlTdQO9/fascB1drekrDVkaKd9PkwBymMlHOiG+qLI=" crossorigin="anonymous"></script>
	<!-- Bootstrap core CSS -->
	<link href="./bootstrap.min.css" rel="stylesheet">
</head>

<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark static-top">
	<div class="container">
		<a class="navbar-brand" href="index.php">Most Friendly App</a>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		</button>
		<div class="collapse navbar-collapse" id="navbarResponsive">
			<ul class="navbar-nav ml-auto">
				<li class="nav-item active">
					<a class="nav-link" href="index.php">Home</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="notes.php">Notes</a>
				</li>
				<li class="nav-item">
					<a class="nav-link" href="logout.php">Logout</a>
				</li>
			</ul>
		</div>
	</div>
</nav>

<main role="main" class="container">
	<?php
		$conn = new mysqli("localhost","admin","admin","dashboard_db");
        if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
        }

        if(isset($_POST['title']) && isset($_POST['body'])){
        	$sql = "INSERT INTO notes (title, body, username) VALUES (?,?,?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sss", $_POST['title'],$_POST['body'],$_SESSION['user']['username']);
            $result = $stmt->execute();
        }

        $sql = "SELECT title, body FROM notes WHERE username = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $_SESSION['user']['username']);
        $stmt->execute();
        $result = $stmt->get_result();
		$data = $result->fetch_assoc();
		echo '<div class="row"><div class="col-xl-6">';
		if($data){
			echo '<h1 class="mt-5">Your notes</h1><hr style="border-top-width:3px">';
			for ($row_no = $result->num_rows - 1; $row_no >= 0; $row_no--) {
			    $result->data_seek($row_no);
			    $notes = $result->fetch_assoc();
				echo "<h2 class=\"mt-3\">".htmlentities($notes["title"])."</h2>";
				echo "<p>".htmlentities($notes["body"])."</p><hr/>";
			}
			echo "</div>";
		}else{
			echo '<p class="mt-5 lead">No notes yet</p></div>';
		}
	?>
	<div class="col-xl-6 mt-5">
		<form class="form-add-note" action="notes.php" method="POST">
		<label for="title" class="sr-only">Title</label>
		<input type="text" name="title" class="form-control" placeholder="Title" required="" autofocus="">
		<label for="body" class="sr-only">Body</label>
		<textarea class="mt-2 form-control" name="body" placeholder="Body" rows="3"></textarea>
		
		<button class="btn btn-primary btn-block mt-2" type="submit">Add note</button>
		</form>
	</div>
</main>

</body>

</html>
