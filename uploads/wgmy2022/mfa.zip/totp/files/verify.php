<?php 
	session_start();
	if (!isset($_SESSION["user"])){
		echo '<meta http-equiv="refresh" content="0;url=login.php">';
		die();
	}
	require 'vendor/autoload.php';
	use OTPHP\TOTP;
?>
<!doctype html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="description" content="">
		<meta name="author" content="Kuki Godam">
		<script src="https://code.jquery.com/jquery-3.4.1.slim.js" integrity="sha256-BTlTdQO9/fascB1drekrDVkaKd9PkwBymMlHOiG+qLI=" crossorigin="anonymous"></script>
		<title>MFA</title>

		<!-- Bootstrap core CSS -->
		<link href="./bootstrap.min.css" rel="stylesheet">

		<!-- Custom styles for this template -->
		<link href="./style.css" rel="stylesheet">
	</head>
	<body class="text-center">
		<div class="col-xl-3">
		<h2>MFA</h2>
		<br>
		<form class="form-signin" action="verify.php" method="POST">
		<?php 
		if(isset($_POST["otp"])){
			if ($_SESSION["pass"] === $_SESSION["user"]["password"]) {
				$otp = TOTP::create($_SESSION["user"]["secret"]);
				if($otp->verify($_POST['otp'])){
					$_SESSION["auth"] = True;
					echo "<h5 class='text-success'>Verified!</h5><p>Redirecting to home page..</p>";
					echo '<meta http-equiv="refresh" content="0;url=index.php">';
					die();
				}
			}
			echo '<meta http-equiv="refresh" content="0;url=login.php">';
		}
		?>
		
		<input type="password" name="otp" class="form-control" placeholder="OTP" required="">
		<button class="btn btn-lg btn-primary btn-block mb-2" type="submit">Verify</button>
		
		</form>
		
		</div>
</body>
</html>
