cd /var/www/html
composer require spomky-labs/otphp
sed -i "s/{put the flag here}/$FLAG/g" /var/www/html/addadmin.php

service php8.1-fpm start
mysqld_safe &

while ! mysql -e "show databases;"; do # Wait for MariaDB
  sleep 1
done

mysql < /setup.sql
nginx
while true; do sleep 1000; done