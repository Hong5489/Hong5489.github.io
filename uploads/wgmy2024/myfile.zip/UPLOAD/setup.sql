CREATE DATABASE myfile_db;

GRANT SELECT,INSERT,UPDATE,DELETE ON myfile_db.* TO 'admin'@'%' IDENTIFIED BY 'admin';
USE myfile_db;

CREATE TABLE files (
        id int NOT NULL AUTO_INCREMENT PRIMARY KEY,
        fileid varchar(32) DEFAULT MD5(RANDOM_BYTES(16)),
        filename varchar(1000) NOT NULL
);

INSERT INTO files (filename) VALUES ("flag.txt");